import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="home-container">
      <h1>Welcome to REZZSHOP</h1>
      <p>Explore our wide range of products and enjoy shopping with us.</p>
      <Link to="/products" className="btn btn-primary">
        Shop Now
      </Link>
    </div>
  );
};

export default Home;