// client/src/pages/Cart.js
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addToCart, removeFromCart } from '../actions/cartActions';

const Cart = () => {
  const cartItems = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
  };

  const handleRemoveFromCart = (productId) => {
    dispatch(removeFromCart(productId));
  };

  return (
    <div className="cart-container">
      <h2>Shopping Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul>
          {cartItems.map((item) => (
            <li key={item.product._id}>
              {item.product.name} - ${item.product.price} x {item.quantity}
              <button onClick={() => handleRemoveFromCart(item.product._id)}>
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      {/* Add checkout button */}
    </div>
  );
};

export default Cart;