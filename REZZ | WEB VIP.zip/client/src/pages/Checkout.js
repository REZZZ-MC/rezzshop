// client/src/pages/Checkout.js
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';

const Checkout = () => {
  const cartItems = useSelector((state) => state.cart.items);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');

  const handleCheckout = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/orders', {
        name,
        email,
        address,
        items: cartItems.map((item) => ({
          product: item.product._id,
          quantity: item.quantity,
        })),
      });
      console.log('Order created:', response.data);
      // Redirect to order history page or clear cart
    } catch (error) {
      console.error('Error during checkout:', error);
    }
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <form onSubmit={handleCheckout}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Address:</label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          ></textarea>
        </div>
        <button type="submit">Place Order</button>
      </form>
    </div>
  );
};

export default Checkout;